
export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  isCreator: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: ProductCategory;
  images: string[];
  downloadUrl?: string;
  fileSize?: string;
  format?: string;
  creatorId: string;
  creator: {
    name: string;
    avatar?: string;
  };
  rating: number;
  reviewCount: number;
  salesCount: number;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  featured: boolean;
}

export interface ProductCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  currency: string;
  status: OrderStatus;
  paymentMethod: string;
  createdAt: string;
  downloadLinks?: { [productId: string]: string };
}

export type OrderStatus = 'pending' | 'completed' | 'failed' | 'refunded';

export interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  available: boolean;
  regions: string[];
}

export interface Analytics {
  totalSales: number;
  totalRevenue: number;
  monthlyRevenue: number[];
  topProducts: Product[];
  recentOrders: Order[];
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  duration: 'monthly' | 'yearly';
  features: string[];
  isPopular?: boolean;
  maxProducts?: number;
  maxDownloads?: number;
  supportLevel: 'basic' | 'premium' | 'enterprise';
}

export interface UserSubscription {
  id: string;
  userId: string;
  planId: string;
  plan: SubscriptionPlan;
  status: 'active' | 'expired' | 'cancelled' | 'trial';
  startDate: string;
  endDate: string;
  trialEndDate?: string;
  isTrialActive: boolean;
  autoRenew: boolean;
}

export interface ChatMessage {
  _id: string | number;
  text: string;
  createdAt: Date;
  user: {
    _id: string | number;
    name: string;
    avatar?: string;
  };
  system?: boolean;
  pending?: boolean;
}

export interface AIResponse {
  message: string;
  confidence: number;
  suggestions?: string[];
  escalateToHuman?: boolean;
}
